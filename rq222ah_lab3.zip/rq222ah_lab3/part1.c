
/*
This function displays values in order 10011001 
The output is sent to LEDs which are connected to 
high nibble is PORTD (7 - 5) while lower nibble is PORTB (3-0)

*/

#include <avr/io.h>


int main(void)
{
	DDRB = DDRB | 0x0F;		// Low nibble of PortB is configured as output
	DDRD = DDRD | 0xF0;		// High nibble of PortD is configured as output
	
	while (1)
    {
		PORTD = PORTD | 0x90;	// Sending 1001 = 9 to high nibble of PortD
		PORTB = PORTB | 0x09;	// Sending 1001 = 9 to lower nibble of PortB
    }
}

