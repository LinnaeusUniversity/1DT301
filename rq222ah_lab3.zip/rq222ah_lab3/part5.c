/*

A function to generate a Dice function on every push of button
A random number in the range of 1 - 6 is generated.

*/

#include <avr/io.h>
#include <stdlib.h>

int main(void)
{
	UBRR0L = 12;			// UBRR sets baud, 12 = 19200 baud at 4 MHz
	UBRR0H = 0x00;			// The higher byte of UBRR register is not required, so kept to 0
	UCSR0B = (1 << TXEN0) | (1 << RXEN0);	// Enabling transmitter and receiver

	char ch;				// a character variable to store received data
	char transmit;			// character to store output character 
	int num_rand;			// variable to store random number.
	
	while (1)
	{
		while (!(UCSR0A & (1<<RXC0)));		// Checks UCSR0A to see if we've completed a receive,
											// meaning data is ready to be collected from UDR
		ch = UDR0;							//  Loads data from UDR,
		
		if (ch == 'r')						// Checks what is the received character 					
		{
			num_rand	= rand ();			// If condition is true, generate a random number.
			transmit	= ((num_rand % 6) + 1) + '0';	// Convert the generated number in character form to transmit.
		}
		else
		{
			transmit	= 'E';				// If the control character is not right send an error message.
		}
		
		while (!(UCSR0A & (1<<UDRE0)));		//  Check if we are ready to send by checking if UDR is empty
		UDR0 = transmit;					//  Load current char into UDR, which transmits it
		while (!(UCSR0A & (1<<RXC0)));		// Receiving two extra characters to tackle CR+LF
	}		
}

