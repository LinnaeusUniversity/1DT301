/*
This function implements a method to toggle all the LEDs that are connected to a port, 
this toggling is triggered with an external interrupt signal
*/

#include <avr/io.h>
#include <avr/interrupt.h>

int main(void) 
{
	EICRA |= 0x03; // Lower two bits are set to 1, to enable ISC00 and ISC01 for rising edge interrupt .
	EIMSK |= 0x01; // INT0 is set to 1 to enable INT0

	// Set data direction for low nibble of PORTB and high nibble of PORTD
	DDRB = 0x0F;		
	DDRD = 0xF0;		// This also sets the lower bit of PD2 to 0 for input. 

	// Resetting B and D to known values
	PORTB = 0x00;		// Showing some random values, alternating LEDs are on/off
	PORTD = 0x00;
	
	sei(); 
	// // Set the global interrupt enable flag here!
	while (1) 
	{
		// Do nothing, the toggle is supposed to happen in the interrupt
	}
}
ISR (INT0_vect)		// Interrupt Service Routine for INT0
{
	PORTB = ~PORTB; // Whenever the interrupt is called, bits on port B and D are toggled 
	PORTD = ~PORTD;
}