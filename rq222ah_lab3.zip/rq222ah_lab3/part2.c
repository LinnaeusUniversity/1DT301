
/*
This function crates formula 1 pattern, as described in task. the pattern is created only 
when the button with PD2 is pressed. 
*/

#include <avr/io.h>
#include <util/delay.h>

void main(void)
{
	DDRB = 0x0F;		// Lower nibble of port B is set to 1 in DDR register to make it output 
	DDRD = 0x00;		// Configuring all bits of portD as input, while we only require PD2.
	
	while (1)
	{
		if ( (PIND & 0x04))			// Keep monitoring PD2 of PORTD, if it is 1 then start the sequence 
		{
			PORTB = 0x08;			// Sending first value to PORTB to turn X000
			_delay_ms (500);		// Add a delay of 500ms which is 0.5 sec
			PORTB = 0x0C;			// // Sending second value to PORTB to turn XX00
			_delay_ms (500);		// Add a delay of 500ms which is 0.5 sec
			PORTB = 0x0E;			// // Sending third value to PORTB to turn XXX0
			_delay_ms (500);		// Add a delay of 500ms which is 0.5 sec
			PORTB = 0x0F;			// // Sending fourth value to PORTB to turn XXXX
			_delay_ms (500);		// Add a delay of 500ms which is 0.5 sec
		}
		else
			PORTB = 0x00;			// Signal is automatically turned off when comes to this point
	}
}

