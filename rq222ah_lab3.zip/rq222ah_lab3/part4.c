/*
This module uses the assembly program to implement serial communication 
which was handed over in lab folder
*/

#include <avr/io.h>

int main(void)
{
	DDRB	|= 0x0F;		// Initializing lower nibble of Port B as output and setting initial value to F 
	PORTB	|= 0x0F;			
	
	DDRD	|= 0xF0;		// Initializing higher nibble of Port D as output and setting initial value to F 
	PORTD   |= 0xF0;			

	UBRR0L = 12;			// UBRR sets baud, 12 = 19200 baud at 4 MHz
	
	UBRR0H = 0x00;			// The higher byte of UBRR register is not required, so kept to 0
	UCSR0B = (1 << TXEN0) | (1 << RXEN0);	// Enabling transmitter and receiver 
	
	unsigned char ch;		// a character variable to store data 
	
	while (1)
	{
		while (!(UCSR0A & (1<<RXC0)));		// Checks UCSR0A to see if we've completed a receive, 
											// meaning data is ready to be collected from UDR
		ch = UDR0;							//  Loads data from UDR,	
			
		PORTB = 0xF0 & ch;					// Higher byte is sent to PORTB while lower byte is sent to PORTD
		PORTD = 0xF0 & ch;					
		
		while (!(UCSR0A & (1<<UDRE0)));		//  Check if we are ready to send by checking if UDR is empty
		UDR0 = ch;							//  Load current char into UDR, which transmits it
	}
}

