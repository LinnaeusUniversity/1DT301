/*
 * GccApplication4.c
 *
 * Created: 01/10/2020 12:40:02
 * Author : rashid
 */ 
#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

volatile char running = 1;  // a char to keep track if the clock is running or not... 
/* USING VOLTATILE CHAR is necessaryy!!!... as i am  changing its value in the ISR*/


int main(void)
{	
	
	DDRA = 0xFF;
	PORTA = 0x00;
	
	DDRD = 0x00;
	
	EICRA = 0x03;  //setting INT0 as external interrupt.. @ PD0 at RISING edge.
	EIMSK = 0x01;  // Enabling INT0
	sei();			// Enabling Global interrupt.
   
    while (1) 
    {
		
		//if the clock is running only then counter is incremented
		if (running == 1){
			PORTA +=1;
			//if overflows, reset to 0
			if (PORTA == 255){
				PORTA == 0;
			}
			_delay_ms(500);
		
			}
    }
	
	
}

ISR(INT0_vect){
	
	//interrupt ISR...
	
	//if NOT running, then start running.
		//else, stop running the clock...
	
	if (running == 0){
	
		running = 1;
	}
	else{
		running = 0;
	}
	_delay_ms(250);
}

