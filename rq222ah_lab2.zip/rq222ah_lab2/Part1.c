/*
 * GccApplication1.c
 *
 * Created: 30/09/2020 09:22:01
 * Author : rashid
 */ 
 #include <avr/io.h>


 int main(void)
 {
	
	 DDRA = 0xFF;// PORTA as output 
	 // Mainloop
	 while (1) {
		 // turn on every other bit on PORTA, pattern 10101010
		 PORTA = 0xAA;
	 }
	 
 }