/*
 * GccApplication2.c
 *
 * Created: 30/09/2020 09:49:08
 * Author : rashid
 */ 
 #include <avr/io.h>
#include <util/delay.h>

 int main(void)
 {
 
	 // PORTA as input
	 DDRA = 0x00;
	 // PORTB as output
	 DDRB = 0xFF;
	 // Mainloop
	 while (1) {
		 
			 if(PINA !=0x00) // Check if any button is pressed
			 {
				 PORTB=0xFF; // Turn on all leds on PORTB
		     }
			 if(PINA==0x00)
			 {
				 PORTB=0x00;
			 }
			 
		 
	 }
	 return 0;
 }
 
