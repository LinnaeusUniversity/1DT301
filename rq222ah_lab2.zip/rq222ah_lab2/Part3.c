/*
 * GccApplication3.c
 *
 * Created: 01/10/2020 12:12:19
 * Author : rashid
 */ 
 #include <avr/io.h>
 #define F_CPU 8000000UL
 #include<avr/delay.h>


 int main(void)
 {
	 // PORTB as output
	 DDRB = 0xFF;
	 // MAINloop
	 while (1) {
		 PORTB=0x00;
		 for(int i=0;i<255;i++)
		 {
			//Increase value by one
			 PORTB=PORTB+1; 
			  _delay_ms(500); // delay of 500ms
		
		 }
	 }
	 
	 
 }