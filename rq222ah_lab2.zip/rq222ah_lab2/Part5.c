/*
 * GccApplication5.c
 *
 * Created: 01/10/2020 16:02:19
 * Author : rashid
 */ 
 #include <avr/io.h>
 #define F_CPU 8000000UL
 #include<avr/delay.h>


 int main(void)
 {
	 // PORTA as input
	 DDRB = 0x00;
	 // PORTB as output
	 DDRB = 0xFF;
	 
	 // Use current time as seed for random generator
	 srand(time(0));
	 
	 // MAINloop
	 while (1) {
		 if(PINA & 0b00000001)
		 {
			 PORTB=(rand() %(6 - 1 + 1)) + 1;
			 _delay_ms(250);
		 }
		 
	 }
 }